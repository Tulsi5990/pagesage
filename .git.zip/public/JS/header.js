function openNav() {
    var x = document.getElementById("myTopnav");
    x.classList.add("responsive");
  }
  
  function closeNav() {
    var x = document.getElementById("myTopnav");
    x.classList.remove("responsive");
  }
  